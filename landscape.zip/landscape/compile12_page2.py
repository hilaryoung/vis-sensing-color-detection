#directory /Users/hilaryyoung/Desktop/*compileVS2_experimental/
from tkinter import *
import tkinter as tk
import csv
import collections
import random

root = Tk()
#ws.configure(width=4000, height=3000)
root.geometry('480x320+0+0')
root.title('Your Pallete')
root['bg']='#585858'

 
def nextPage():
    root.destroy()
    import compile12_page1


#COLOR COUNTER
def convertTuple(tup):
    str =  ''.join(tup)
    return str

with open('loopColor2.csv') as csvFile:
        csvReader = csv.reader(csvFile)
        rows = list(csvReader)     

listOfColors =[]
for i in range (-31,0): 
    if rows[i]:
        color = convertTuple(rows[i])
        listOfColors.append(color) 
    else:
        print("nothing")


redCol = 0
orangeCol = 0
goldCol =0
greenCol =0
blueCol =0
purplCol = 0
pinkCol = 0
brownCol = 0
blackCol = 0

for i in listOfColors:
    if i == "crimson":
        redCol += 1
    if i == "orange":
        orangeCol += 1
    if i == "gold":
        goldCol += 1
    if i == "green":
        greenCol += 1
    if i == "steelblue":
        blueCol += 1
    if i == "orchid":
        purplCol += 1
    if i == "pink":
        pinkCol += 1
    if i == "sienna":
        brownCol += 1
    if i == "black":
        blackCol += 1

print("num of red: ",redCol)
print("num of orange: ", orangeCol)
print("num of yellow: ", goldCol)
print("num of green: ", greenCol)
print("num of blue: ", blueCol)
print("num of purple: ", purplCol)
print("num of pink: ",pinkCol)
print("num of brown: ", brownCol)
print("num of black: ", blackCol)


multiple = 40
x1 = 5
x2 = 280
y1= 10
y2 = 160

#POSITIONING
redBox = tk.Frame(root, bg="crimson", width=(redCol * multiple), height=(redCol * multiple))
redBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
redBox.pack_propagate(0)

orangeBox = tk.Frame(root, bg="orange", width=(orangeCol * multiple), height=(orangeCol * multiple))
orangeBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
orangeBox.pack_propagate(0)

goldBox = tk.Frame(root, bg="gold", width=(goldCol * multiple), height=(goldCol * multiple))
goldBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
goldBox.pack_propagate(0)

greenBox = tk.Frame(root, bg="green", width=(greenCol * multiple), height=(greenCol * multiple))
greenBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
greenBox.pack_propagate(0)

blueBox = tk.Frame(root, bg="steelblue", width=(blueCol * multiple), height=(blueCol * multiple))
blueBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
blueBox.pack_propagate(0)

purpBox = tk.Frame(root, bg="orchid", width=(purplCol * multiple), height=(purplCol * multiple))
purpBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
purpBox.pack_propagate(0)

pinkBox = tk.Frame(root, bg="pink", width=(pinkCol * multiple), height=(pinkCol * multiple))
pinkBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
pinkBox.pack_propagate(0)

brownBox = tk.Frame(root, bg="sienna", width=(brownCol * multiple), height=(brownCol * multiple))
brownBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
brownBox.pack_propagate(0)

blackBox = tk.Frame(root, bg="black", width=(blackCol * multiple), height=(blackCol * multiple))
blackBox.place(x=random.randint(x1, x2) , y=random.randint(y1,y2))
blackBox.pack_propagate(0)


#BACK BUTTON
homeButton = Button(root, text="Home",command=nextPage)
homeButton.place(x=250, y=215)

root.mainloop()